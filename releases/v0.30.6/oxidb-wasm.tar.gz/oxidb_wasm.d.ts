/* tslint:disable */
/* eslint-disable */

/**
 * Delete documents matching a query. Returns number of deleted documents.
 */
export function _delete(collection: string, query: string): number;

/**
 * Run an aggregation pipeline. Returns JSON array string.
 */
export function aggregate(collection: string, pipeline: string): string;

/**
 * Count documents matching a query.
 */
export function count(collection: string, query: string): number;

/**
 * Create an index on a field.
 */
export function create_index(collection: string, field: string): void;

/**
 * Drop a collection.
 */
export function drop_collection(name: string): void;

/**
 * Find documents matching a query. Returns JSON array string.
 */
export function find(collection: string, query: string): string;

/**
 * Find a single document matching a query. Returns JSON string or "null".
 */
export function find_one(collection: string, query: string): string;

/**
 * Initialize the in-memory database. Must be called before any other operation.
 */
export function init(): void;

/**
 * Insert a document into a collection. Returns the assigned document ID.
 */
export function insert(collection: string, json_doc: string): string;

/**
 * Insert multiple documents. Expects a JSON array string. Returns JSON array of IDs.
 */
export function insert_many(collection: string, json_docs: string): string;

/**
 * List all collection names. Returns JSON array string.
 */
export function list_collections(): string;

/**
 * Update documents matching a query. Returns number of modified documents.
 */
export function update(collection: string, query: string, update_doc: string): number;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly init: () => void;
    readonly insert: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly insert_many: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly find: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly find_one: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly update: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly _delete: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly count: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly create_index: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly list_collections: (a: number) => void;
    readonly drop_collection: (a: number, b: number, c: number) => void;
    readonly aggregate: (a: number, b: number, c: number, d: number, e: number) => void;
    readonly __wbindgen_export: (a: number) => void;
    readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
    readonly __wbindgen_export2: (a: number, b: number) => number;
    readonly __wbindgen_export3: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_export4: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
