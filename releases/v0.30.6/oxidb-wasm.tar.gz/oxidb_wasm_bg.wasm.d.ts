/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const init: () => void;
export const insert: (a: number, b: number, c: number, d: number, e: number) => void;
export const insert_many: (a: number, b: number, c: number, d: number, e: number) => void;
export const find: (a: number, b: number, c: number, d: number, e: number) => void;
export const find_one: (a: number, b: number, c: number, d: number, e: number) => void;
export const update: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
export const _delete: (a: number, b: number, c: number, d: number, e: number) => void;
export const count: (a: number, b: number, c: number, d: number, e: number) => void;
export const create_index: (a: number, b: number, c: number, d: number, e: number) => void;
export const list_collections: (a: number) => void;
export const drop_collection: (a: number, b: number, c: number) => void;
export const aggregate: (a: number, b: number, c: number, d: number, e: number) => void;
export const __wbindgen_export: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export2: (a: number, b: number) => number;
export const __wbindgen_export3: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export4: (a: number, b: number, c: number) => void;
